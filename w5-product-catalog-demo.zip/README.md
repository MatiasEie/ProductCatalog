# W5 product catalog – demo assets

Pakken inneholder:

- `catalog.json`
- `images/misc`
- `images/antennas`
- `images/cabinets`
- `images/monitors`
- `images/targets`

Alle produktbilder er demoillustrasjoner i WebP-format.
De er laget med samme filnavn som produktets `id`.

Du kan senere erstatte et bilde med ekte produktfoto ved å beholde
samme mappenavn og filnavn. Da trenger du ikke endre `catalog.json`.

Eksempel:
`images/targets/h4d.webp`
